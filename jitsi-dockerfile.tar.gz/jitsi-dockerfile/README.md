https://github.com/jitsi/docker-jitsi-meet

```
cd based-on-stable-5870/jvb
docker build . -t jimlintw/jvb:stable-5870-rev

cd based-on-stable-5870/prosody
docker build . -t jimlintw/prosody:stable-5870-rev

cd based-on-stable-5870/jicofo
docker build . -t jimlintw/jicofo:stable-5870-rev

cd based-on-stable-5870/web
docker build . -t jimlintw/web:stable-5870-rev
```

* debian -> base -> base-java -> jvb
  - volume: /config
  - expose:
* debian -> base -> base-java -> prosody
  - volume: /config /prosody-plugins-custom
  - expose: 5222 5347 5280
* debian -> base -> web
  - volume: /config /usr/share/jitsi-meet/transcripts
  - expose: 80 443
* debian -> base -> jicofo
  - volume: /config
  - expose:

entrypoint
* 定義在 base 
* /init
  這是標準的 debian 開機啟動程序
  https://www.debian.org/doc/manuals/debian-reference/ch03.zh-tw.html

base image 安裝了 s6 overlay
* 這是客製化的開機啟動程序
  https://github.com/just-containers/s6-overlay
  https://github.com/just-containers/s6-overlay#init-stages
  https://github.com/just-containers/s6-overlay#executing-initialization-andor-finalization-tasks
  https://github.com/just-containers/s6-overlay#writing-a-service-script
  http://skarnet.org/software/s6/overview.html
* 也使用 /init
* /etc/fix-attrs.d/     ... for fixing ownership permissions    [1] 執行順序
* /etc/cont-init.d/     ... for initialization                  [2]
  jvb: 10-config
  prosody: 10-config
  web: 10-config
  jicofo: 10-config
* /etc/sercices.d/                                              [3]
  jvb: jvb/run
  prosody: 10-saslauthd/run
           prosody/run
  web: cron/run
       nginx/run
  jicofo: jicofo/run
* /etc/cont-finish.d/   ... for finalization

/etc/cont-init.d/10-config
* 從 /defaults 內容, 加上環境變數內容, 製作 /config 的內容
  /defaults 內容從 rootfs/defaults 來的

base image 安裝了 tpl 指令
rootfs/usr/bin/tpl
base image 安裝了 frep 指令
https://github.com/subchen/frep