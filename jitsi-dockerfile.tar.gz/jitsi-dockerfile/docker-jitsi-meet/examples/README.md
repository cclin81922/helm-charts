# Community Examples

The examples contained in this directory have been provided by the community
and allow users to run the container setup in scenarios other than the
default one (using Docker Compose).

Since they are maintained by the community, they may not provide the same
features as the default setup.

No support is provided for these, but if you found a bug and can fix it
we'll be happy to accept a Pull-Request to fix it!
