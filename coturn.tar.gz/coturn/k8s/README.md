kubectl create ns coturn

kubectl -n coturn create configmap coturn-tls --from-file=tls

kubectl -n coturn create configmap coturn-conf --from-file=conf

kubectl -n coturn apply -f deployment.yaml

kubectl -n coturn apply -f service.yaml

kubectl -n coturn run -i --tty turn-client --image=coturn/coturn:4.5 -- /bin/bash
    # https://www.cnblogs.com/mobilecard/p/6544731.html
    # To test stun
    turnutils_stunclient coturn
    # OUTPUT
    # 0: : IPv4. UDP reflexive addr: 10.1.0.121:58811
    # 0: : IPv4. UDP reflexive addr: 10.1.0.121:58811

    # https://www.cnblogs.com/mobilecard/p/6544750.html
    # # To test turn
    turnutils_uclient -v -u coturn -w coturn coturn
    # OUTPUT
    # 0: : IPv4. Connected from: 10.1.0.121:38318
    # 0: : IPv4. Connected from: 10.1.0.121:38318
    # 0: : IPv4. Connected to: 10.99.230.9:3478
    # 0: : allocate sent
    # 0: : allocate response received: 
    # 0: : allocate sent
    # 0: : allocate response received: 
    # 0: : success
    # 0: : IPv4. Received relay addr: 10.99.230.9:14924
    # 0: : clnet_allocate: rtv=11246272209760896008
    # 0: : refresh sent
    # 0: : refresh response received: 
    # 0: : success
    # 0: : IPv4. Connected from: 10.1.0.121:57989
    # 0: : IPv4. Connected to: 10.99.230.9:3478
    # 0: : IPv4. Connected from: 10.1.0.121:35051
    # 0: : IPv4. Connected to: 10.99.230.9:3478
    # 0: : allocate sent
    # 0: : allocate response received: 
    # 0: : allocate sent
    # 0: : allocate response received: 
    # 0: : success
    # 0: : IPv4. Received relay addr: 10.99.230.9:14925
    # 0: : clnet_allocate: rtv=0
    # 0: : refresh sent
    # 0: : refresh response received: 
    # 0: : success
    # 0: : allocate sent
    # 0: : allocate response received: 
    # 0: : allocate sent
    # 0: : allocate response received: 
    # 0: : success
    # 0: : IPv4. Received relay addr: 10.99.230.9:17416
    # 0: : clnet_allocate: rtv=17676234033109220288
    # 0: : refresh sent
    # 0: : refresh response received: 
    # 0: : success
    # 0: : channel bind sent
    # 0: : cb response received: 
    # 0: : channel bind: error 403 (Forbidden IP)

kubectl -n coturn exec -it $(kubectl -n coturn get ...) -- /bin/bash
    https://blog.csdn.net/weixin_41740391/article/details/113498212
    # 在服务端启动 peer
    turnutils_peer -v -p 2345
    # OUTPUT
    # 0: : udp_create_server_socket:66:start
    # 0: : udp_create_server_socket:66:start
    # 0: : udp_create_server_socket:98:end
    # 0: : udp_create_server_socket:66:start
    # 0: : udp_create_server_socket:98:end
    # 0: : udp_create_server_socket:66:start
    # 0: : udp_create_server_socket:98:end
    # 0: : udp_create_server_socket:66:start
    # 0: : udp_create_server_socket:98:end

kubectl -n coturn run -i --tty turn-client --image=coturn/coturn:4.5 -- /bin/bash
    https://blog.csdn.net/weixin_41740391/article/details/113498212
    # 在客户端启动：测试udp 数据穿越
    turnutils_uclient -v -u coturn -w coturn coturn -e coturn -r 2345 coturn
    # 0: : IPv4. Connected from: 10.1.0.135:49824
    # 0: : IPv4. Connected from: 10.1.0.135:49824
    # 0: : IPv4. Connected to: 10.99.230.9:3478
    # 0: : allocate sent
    # 0: : allocate response received: 
    # 0: : allocate sent
    # 0: : allocate response received: 
    # 0: : success
    # 0: : IPv4. Received relay addr: 10.1.0.132:16990
    # 0: : clnet_allocate: rtv=676228892530983028
    # 0: : refresh sent
    # 0: : refresh response received: 
    # 0: : success
    # 0: : IPv4. Connected from: 10.1.0.135:45397
    # 0: : IPv4. Connected to: 10.99.230.9:3478
    # 0: : IPv4. Connected from: 10.1.0.135:56717
    # 0: : IPv4. Connected to: 10.99.230.9:3478
    # 0: : allocate sent
    # 0: : allocate response received: 
    # 0: : allocate sent
    # 0: : allocate response received: 
    # 0: : success
    # 0: : IPv4. Received relay addr: 10.1.0.132:16991
    # 0: : clnet_allocate: rtv=0
    # 0: : refresh sent
    # 0: : refresh response received: 
    # 0: : success
    # 0: : allocate sent
    # 0: : allocate response received: 
    # 0: : allocate sent
    # 0: : allocate response received: 
    # 0: : success
    # 0: : IPv4. Received relay addr: 10.1.0.132:16500
    # 0: : clnet_allocate: rtv=2239667090731185077
    # 0: : refresh sent
    # 0: : refresh response received: 
    # 0: : success
    # 0: : channel bind sent
    # 0: : cb response received: 
    # 0: : success: 0x72d8
    # 0: : channel bind sent
    # 0: : cb response received: 
    # 0: : success: 0x72d8
    # 0: : channel bind sent
    # 0: : cb response received: 
    # 0: : success: 0x5d1f
    # 0: : channel bind sent
    # 0: : cb response received: 
    # 0: : success: 0x5d1f
    # 0: : channel bind sent
    # 0: : cb response received: 
    # 0: : success: 0x5d14
    # 0: : Total connect time is 0
    # 1: : start_mclient: msz=2, tot_send_msgs=0, tot_recv_msgs=0, tot_send_bytes ~ 0, tot_recv_bytes ~ 0
    # 2: : start_mclient: msz=2, tot_send_msgs=0, tot_recv_msgs=0, tot_send_bytes ~ 0, tot_recv_bytes ~ 0
    # 3: : start_mclient: msz=2, tot_send_msgs=0, tot_recv_msgs=0, tot_send_bytes ~ 0, tot_recv_bytes ~ 0
    # 4: : start_mclient: msz=2, tot_send_msgs=5, tot_recv_msgs=0, tot_send_bytes ~ 500, tot_recv_bytes ~ 0
    # 5: : start_mclient: msz=2, tot_send_msgs=10, tot_recv_msgs=0, tot_send_bytes ~ 1000, tot_recv_bytes ~ 0
    # 6: : start_mclient: msz=2, tot_send_msgs=10, tot_recv_msgs=0, tot_send_bytes ~ 1000, tot_recv_bytes ~ 0
    # 7: : start_mclient: msz=2, tot_send_msgs=10, tot_recv_msgs=0, tot_send_bytes ~ 1000, tot_recv_bytes ~ 0
    # 8: : start_mclient: msz=2, tot_send_msgs=10, tot_recv_msgs=0, tot_send_bytes ~ 1000, tot_recv_bytes ~ 0
    # 9: : start_mclient: msz=2, tot_send_msgs=10, tot_recv_msgs=0, tot_send_bytes ~ 1000, tot_recv_bytes ~ 0
    # 10: : start_mclient: msz=2, tot_send_msgs=10, tot_recv_msgs=0, tot_send_bytes ~ 1000, tot_recv_bytes ~ 0
    # 11: : start_mclient: msz=2, tot_send_msgs=10, tot_recv_msgs=0, tot_send_bytes ~ 1000, tot_recv_bytes ~ 0
    # 12: : start_mclient: msz=2, tot_send_msgs=10, tot_recv_msgs=0, tot_send_bytes ~ 1000, tot_recv_bytes ~ 0
    # 13: : start_mclient: msz=2, tot_send_msgs=10, tot_recv_msgs=0, tot_send_bytes ~ 1000, tot_recv_bytes ~ 0
    # 13: : done, connection 0x7f0c9d183010 closed.
    # 14: : start_mclient: msz=1, tot_send_msgs=10, tot_recv_msgs=0, tot_send_bytes ~ 1000, tot_recv_bytes ~ 0
    # 14: : done, connection 0x7f0c9d162010 closed.
    # 14: : start_mclient: tot_send_msgs=10, tot_recv_msgs=0
    # 14: : start_mclient: tot_send_bytes ~ 1000, tot_recv_bytes ~ 0
    # 14: : Total transmit time is 14
    # 14: : Total lost packets 10 (100.000000%), total send dropped 0 (0.000000%)
    # 14: : Average round trip delay 0.000000 ms; min = 4294967295 ms, max = 0 ms
    # 14: : Average jitter -nan ms; min = 4294967295 ms, max = 0 ms