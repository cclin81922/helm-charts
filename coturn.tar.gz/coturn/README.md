[ Utility ]
https://webrtc.github.io/samples/src/content/peerconnection/trickle-ice/

[ K8s ]
kubectl run coturn --image coturn/coturn:4.5
# TODO coturn.conf
# TODO TLS key and cert

[ Docker ]
https://github.com/coturn/coturn/tree/master/docker/coturn
# docker run -d -p 3478:3478 -p 49152-65535:49152-65535/udp coturn/coturn
# Q: Why so many ports opened?
# A: As per RFC 5766 Section 6.2, these are the ports that the TURN server will use to exchange media.
#
# use the host network directly (recommended, as Docker performs badly with large port ranges)
# docker run -d --network=host coturn/coturn 
# bind: Cannot assign requested address
# Cannot bind local socket to addr: Cannot assign requested address
# 0: : Trying to bind fd 109 to <[fc00:f853:ccd:e793::1]:3478>: errno=99
# 0: : Cannot bind DTLS/UDP listener socket to addr [fc00:f853:ccd:e793::1]:3478
# 0: : ERROR: Fatal final failure: cannot bind DTLS/UDP listener socket to addr [fc00:f853:ccd:e793::1]:3478



---
https://github.com/Monogramm/docker-coturn
# This Docker repository provides the Coturn TURN server with a configuration suitable to use with Spreed WebRTC or NextCloud Talk.



---
https://meetrix.io/blog/webrtc/turnserver/long_term_cred.html
# How to Setup a Coturn Docker Image With Long Term Credentials Mechanism Support.



[ Others ]
https://stackoverflow.com/questions/51566225/nginx-load-balancing-a-turn-server

https://snippetinfo.net/media/2237
# make install
https://codertw.com/%E7%A8%8B%E5%BC%8F%E8%AA%9E%E8%A8%80/492186/
# make install
# listening-ip與relay-ip採用內網ip，external-ip是外網的ip
# ICE測試Relay地址回來的是你的ip才算穿透成功
# turn 包含了stun的功能，所以只需要部署turn伺服器即可
# 如果網路無法穿透的時候就需要 turn 伺服器來保證視訊通話的成功率
[x] https://github.com/aryannarora/coturn-gcp-scripts (out of date)
# make install
# GCP
[x] https://medium.com/@virtualdruid70/webrtc-%E5%9C%A8gcp%E4%B8%8A%E6%9E%B6%E8%A8%ADcoturn-stun-turn-server-part1-5dc17d395864
# 設定防火牆敞開UDP port 49152–65535
# GCP

---
https://meetrix.io/blog/webrtc/coturn/installation.html
# Certbot + letsencrypt
# Long Term Credentials Mechanism
# Time-Limited Credentials Mechanism
# Ubuntu 18.04
# sudo apt-get -y install coturn
# Firewall Rules
1. 80 : TCP # if you need to setup coturn with SSL          # 只是用來取得 letsencrypt 憑證
2. 443 : TCP # if you need to setup coturn with SSL         ＃ 應該是 both TCP & UDP. 其他文件都是 both
3. 3478 : UDP                                               # 應該是 both TCP & UDP. 其他文件都是 both
4. 10000–20000 : UDP

[ o ] Ubuntu 18.04
[ o ] Firewall Rules t80,t443,u3478,u10000-20000

sudo apt-get -y update
sudo apt-get -y install coturn
sudo vim /etc/default/coturn
    TURNSERVER_ENABLED=1    # to run Coturn as an automatic system service daemon
sudo vim /etc/turnserver.conf
    # Long Term Credential Mechanism        [ o ]
    realm=coturn.cclin.work
    fingerprint
    listening-ip=0.0.0.0
    external-ip=<EXTERNAL_IP>/<INTERNAL_IP> #or just the external ip    # e.g., "35.226.155.237" in my case
    listening-port=3478
    min-port=10000
    max-port=20000
    log-file=/var/log/turnserver.log
    verbose
    user=cclin:pass                     #
    lt-cred-mech                        #

    # Time-Limited Credentials Mechanism    [ o ]
    realm=coturn.cclin.work
    fingerprint
    listening-ip=0.0.0.0
    external-ip=<EXTERNAL_IP>/<INTERNAL_IP> #or just the external ip    # e.g., "35.226.155.237" in my case
    listening-port=3478
    min-port=10000
    max-port=20000
    log-file=/var/log/turnserver.log
    verbose
    static-auth-secret=<YOUR_SECRET>    # e.g., "pass" in my case
sudo service coturn restart

# Certbot + letsencrypt
sudo apt-get -y  update &&\
sudo apt-get -y install software-properties-common &&\
sudo add-apt-repository -y universe &&\
sudo add-apt-repository -y ppa:certbot/certbot &&\
sudo apt-get -y update &&\
sudo apt-get -y install certbot
sudo certbot certonly --standalone

sudo vim /etc/turnserver.conf
    # +TLS
    server-name=coturn.cclin.work
    cert=/etc/letsencrypt/live/coturn.cclin.work/cert.pem
    pkey=/etc/letsencrypt/live/coturn.cclin.work/privkey.pem
    listening-port=443                          # typo? SHOULD BE tls-listening-port=443
sudo service coturn restart

---
https://yuanchieh.page/posts/2020/2020-09-21_aws-coturn-server-%E6%9E%B6%E8%A8%AD%E6%95%99%E5%AD%B8/
# 2020/12/04更新：目前 4.5.2 可以支援 prometheus 囉，可是只有支援 Debian，其他平台尚未支援，另外要注意直接用 apt-get install coturn 版本目前是不支援 prometheus，需要自己手動編譯喔
# Warning: 撰文時開啟 prometheus 會有記憶體問題，建議先不要使用喔，詳見 github issue https://github.com/coturn/coturn/issues/666
# cli-password 錯誤可以先忽略
# sudo apt-get -y install coturn
# 先設定 AWS security group，開放以下的 port
# 使用 Coturn 自帶的 test tool
#   turnutils_uclient -T <server ip>
#   turnutils_stunclient <server ip>
# 用瀏覽器開啟 WebRTC samples Trickle ICE
1. 3478: UDP+TCP // TURN Server 接收 request 的 port 
2. 5394: UDP+TCP  // TURN Server 接收 TLS request 的 port 
3. 49152-65536: UDP+TCP  // 實際連線的 Socket Port range


---
https://ourcodeworld.com/articles/read/1175/how-to-create-and-configure-your-own-stun-turn-server-with-coturn-in-ubuntu-18-04
# About Error 701: Note that this happens because the tool has a bug on most recent browsers, however as long as you are able to re-run the test pressing Gather candidates again and again (so the gather candidates button doesn't block) everything should be ok with the STUN/TURN server.
# STUN server port is 3478 for UDP and TCP, and 5349 for TLS.
# sudo apt-get install coturn
# Requirements
1. An Ubuntu server (18.04 in our case).
2. Know the public IP of your server, in our case we will use our server public IP 209.126.124.122.
3. Own a domain and have access to the DNS manager as you will need to create 2 subdomains (the domain will be ourcodeworld.com in our case and we have it hosted on goDaddy).
4. SSL Certificates for the subdomains (preferably a certificate with wildcard e.g *.ourcodeworld.com). Without the secure protocol, your server implementation won't be completed and after using it on your WebRTC projects with HTTPS it won't work, so be smart and avoid headaches, buy a SSL certificate or get a free one with LetsEncrypt.


---
https://docs.bigbluebutton.org/2.2/setup-turn-server.html#setup-a-turn-server
# sudo apt-get install coturn
# Required DNS Entry
1. You need to setup a fully qualified domain name that resolves to the external IP address of your turn server.
2. You’ll use this domain name to generate a TLS certificate using Let’s Encrypt (next section).

# Required Ports
1. On the coturn server, you need to have the following ports (in addition port 22) available for BigBlueButton clients to connect (port 3478 and 443) and 
2. for coturn to connect to your BigBlueButton server (32768 - 65535).

Ports		Protocol	Description
3478		TCP/UDP		coturn listening port
443		TCP/UDP		TLS listening port
32768-65535	UDP		relay ports range
