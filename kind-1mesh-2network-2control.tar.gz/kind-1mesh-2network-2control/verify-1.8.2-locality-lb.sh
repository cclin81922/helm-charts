# VAR setup istio version
ISTIO=../istio-1.8.2

# clean sample namesapce
for cluster in mc1 mc2
do 
    kubectl --context="$cluster" delete ns sample
done

# https://istio.io/latest/docs/tasks/traffic-management/locality-load-balancing/

kubectl --context mc1 label node mesh-cluster1-control-plane topology.kubernetes.io/region=region1 --overwrite
kubectl --context mc1 label node mesh-cluster1-control-plane topology.kubernetes.io/zone=zone1 --overwrite
kubectl --context mc2 label node mesh-cluster2-control-plane topology.kubernetes.io/region=region2 --overwrite
kubectl --context mc2 label node mesh-cluster2-control-plane topology.kubernetes.io/zone=zone3  --overwrite

cat <<EOF > verify-1.8.2-locality/sample.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: sample
  labels:
    istio-injection: enabled
EOF

for cluster in mc1 mc2
do 
    kubectl --context="$cluster" apply -f verify-1.8.2-locality/sample.yaml;
done

for LOC in "region1.zone1" "region2.zone3";
do
    $ISTIO/samples/helloworld/gen-helloworld.sh --version "$LOC" > verify-1.8.2-locality/"helloworld-${LOC}.yaml";
done

kubectl apply --context mc1 -n sample -f verify-1.8.2-locality/helloworld-region1.zone1.yaml
kubectl apply --context mc2 -n sample -f verify-1.8.2-locality/helloworld-region2.zone3.yaml

kubectl apply --context mc1 -f $ISTIO/samples/sleep/sleep.yaml -n sample

for cluster in mc1 mc2;
do
  kubectx $cluster
  kubectl wait -n sample --timeout 1m --for=condition=ready pod -l app=helloworld
done

cat <<EOF > verify-1.8.2-locality/locality-failover.yaml
apiVersion: networking.istio.io/v1beta1
kind: DestinationRule
metadata:
  name: helloworld
spec:
  host: helloworld.sample.svc.cluster.local
  trafficPolicy:
    connectionPool:
      http:
        maxRequestsPerConnection: 1
    loadBalancer:
      simple: ROUND_ROBIN
      localityLbSetting:
        enabled: true
        failover:
          - from: region1
            to: region2
    outlierDetection:
      consecutive5xxErrors: 1
      interval: 1s
      baseEjectionTime: 1m
EOF

kubectl --context mc1 apply -n sample -f verify-1.8.2-locality/locality-failover.yaml

kubectx mc1
for _ in {1..10};
do
  kubectl exec -n sample -c sleep \
      "$(kubectl get pod -n sample -l \
      app=sleep -o jsonpath='{.items[0].metadata.name}')" \
      -- curl -sS helloworld.sample:5000/hello
done
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-4m7t5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-4m7t5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-4m7t5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-4m7t5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-4m7t5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-4m7t5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-4m7t5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-4m7t5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-4m7t5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-4m7t5

# simulate failover
kubectx mc1
kubectl exec \
  "$(kubectl get pod -n sample -l app=helloworld \
  -l version=region1.zone1 -o jsonpath='{.items[0].metadata.name}')" \
  -n sample -c istio-proxy -- curl -sSL -X POST 127.0.0.1:15000/drain_listeners
# OK

kubectx mc1
for _ in {1..10};
do
  kubectl exec -n sample -c sleep \
      "$(kubectl get pod -n sample -l \
      app=sleep -o jsonpath='{.items[0].metadata.name}')" \
      -- curl -sS helloworld.sample:5000/hello
done
# Hello version: region2.zone3, instance: helloworld-region2.zone3-5565df8869-2t95p
# Hello version: region2.zone3, instance: helloworld-region2.zone3-5565df8869-2t95p
# Hello version: region2.zone3, instance: helloworld-region2.zone3-5565df8869-2t95p
# Hello version: region2.zone3, instance: helloworld-region2.zone3-5565df8869-2t95p
# Hello version: region2.zone3, instance: helloworld-region2.zone3-5565df8869-2t95p
# Hello version: region2.zone3, instance: helloworld-region2.zone3-5565df8869-2t95p
# Hello version: region2.zone3, instance: helloworld-region2.zone3-5565df8869-2t95p
# Hello version: region2.zone3, instance: helloworld-region2.zone3-5565df8869-2t95p
# Hello version: region2.zone3, instance: helloworld-region2.zone3-5565df8869-2t95p
# Hello version: region2.zone3, instance: helloworld-region2.zone3-5565df8869-2t95p

# simulate failback
kubectx mc1
kubectl delete po \
  "$(kubectl get pod -n sample -l app=helloworld \
  -l version=region1.zone1 -o jsonpath='{.items[0].metadata.name}')" \
  -n sample

kubectx mc1
for _ in {1..10};
do
  kubectl exec -n sample -c sleep \
      "$(kubectl get pod -n sample -l \
      app=sleep -o jsonpath='{.items[0].metadata.name}')" \
      -- curl -sS helloworld.sample:5000/hello
done
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-qdhb5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-qdhb5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-qdhb5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-qdhb5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-qdhb5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-qdhb5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-qdhb5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-qdhb5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-qdhb5
# Hello version: region1.zone1, instance: helloworld-region1.zone1-5f557c74df-qdhb5