# VAR setup istio version
ISTIO=../istio-1.10.0

# Create 2 clusters
kind create cluster --name mesh-cluster1
kind create cluster --name mesh-cluster2

# Setup kubeconfig contexts
kubectx mc1=kind-mesh-cluster1
kubectx mc2=kind-mesh-cluster2

# VAR fetch kind api servers 
CLUSTER1_API_SERVER=$(kubectl --context mc1 get node -o jsonpath='{.items[0].status.addresses[0].address}')
CLUSTER2_API_SERVER=$(kubectl --context mc2 get node -o jsonpath='{.items[0].status.addresses[0].address}')

# Setup kind load balancers (https://kind.sigs.k8s.io/docs/user/loadbalancer/)
for cluster in mc1 mc2;
do
    kubectx $cluster
    kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/namespace.yaml
    kubectl create secret generic -n metallb-system memberlist --from-literal=secretkey="$(openssl rand -base64 128)" 
    kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/metallb.yaml
    kubectl apply -f https://kind.sigs.k8s.io/examples/loadbalancer/usage.yaml
done

cat <<YAML | kubectl --context mc1 apply -f -
apiVersion: v1
kind: ConfigMap
metadata:
  namespace: metallb-system
  name: config
data:
  config: |
    address-pools:
    - name: default
      protocol: layer2
      addresses:
      - 172.18.255.200-172.18.255.250
YAML

cat <<YAML | kubectl --context mc2 apply -f -
apiVersion: v1
kind: ConfigMap
metadata:
  namespace: metallb-system
  name: config
data:
  config: |
    address-pools:
    - name: default
      protocol: layer2
      addresses:
      - 172.18.255.100-172.18.255.150
YAML

# Setup istio ca (https://istio.io/latest/docs/tasks/security/cert-management/plugin-ca-cert/)
for cluster in mc1 mc2;
do
    kubectx $cluster
    kubectl create namespace istio-system
    kubectl create secret generic cacerts -n istio-system \
      --from-file=$ISTIO/samples/certs/ca-cert.pem \
      --from-file=$ISTIO/samples/certs/ca-key.pem \
      --from-file=$ISTIO/samples/certs/root-cert.pem \
      --from-file=$ISTIO/samples/certs/cert-chain.pem
done

# Setup istio control plane (https://istio.io/latest/docs/setup/install/multicluster/multi-primary_multi-network/)

  # 1. Set the default network for cluster1, cluster2
kubectl --context mc1 label namespace istio-system topology.istio.io/network=network1
kubectl --context mc2 label namespace istio-system topology.istio.io/network=network2

  # 2. Configure cluster1, cluster2 as a primary
cat <<EOF | $ISTIO/bin/istioctl --context mc1 install -f - -y
apiVersion: install.istio.io/v1alpha1
kind: IstioOperator
spec:
  values:
    global:
      meshID: mesh1
      multiCluster:
        clusterName: cluster1
      network: network1
EOF

cat <<EOF | $ISTIO/bin/istioctl --context mc2 install -f - -y
apiVersion: install.istio.io/v1alpha1
kind: IstioOperator
spec:
  values:
    global:
      meshID: mesh1
      multiCluster:
        clusterName: cluster2
      network: network2
EOF

  # 3. Install the east-west gateway in cluster1, cluster2
$ISTIO/samples/multicluster/gen-eastwest-gateway.sh --mesh mesh1 --cluster cluster1 --network network1 | $ISTIO/bin/istioctl --context mc1 install -f - -y
$ISTIO/samples/multicluster/gen-eastwest-gateway.sh --mesh mesh1 --cluster cluster2 --network network2 | $ISTIO/bin/istioctl --context mc2 install -f - -y

  # 4. Expose services in cluster1, cluster2
for cluster in mc1 mc2;
do
    kubectx $cluster
    kubectl apply -n istio-system -f $ISTIO/samples/multicluster/expose-services.yaml
done

  # 5. Enable Endpoint Discovery ***
$ISTIO/bin/istioctl --context mc1 x create-remote-secret --name=cluster1 | sed '1,2d' | sed "s|server: https://127.0.0.1:[0-9]*|server: https://$CLUSTER1_API_SERVER:6443|" | kubectl --context mc2 apply -f -
$ISTIO/bin/istioctl --context mc2 x create-remote-secret --name=cluster2 | sed '1,2d' | sed "s|server: https://127.0.0.1:[0-9]*|server: https://$CLUSTER2_API_SERVER:6443|" | kubectl --context mc1 apply -f -

# Congratulations! You successfully installed an Istio mesh across multiple primary clusters on different networks!

# Verify endpoint discovery

  # 1. Install sample application
for cluster in mc1 mc2;
do
  kubectx $cluster
  kubectl create namespace sample
  kubectl label namespace sample istio-injection=enabled
  kubectl apply -f $ISTIO/samples/helloworld/helloworld.yaml -l service=helloworld -n sample
  kubectl apply -f $ISTIO/samples/sleep/sleep.yaml -n sample

  kubectl apply -n sample -f - <<EOF
apiVersion: security.istio.io/v1beta1
kind: PeerAuthentication
metadata:
  name: default
spec:
  mtls:
    mode: STRICT
EOF
done

kubectl --context mc1 apply -f $ISTIO/samples/helloworld/helloworld.yaml -l version=v1 -n sample
kubectl --context mc2 apply -f $ISTIO/samples/helloworld/helloworld.yaml -l version=v2 -n sample

  # 2. Verifying Cross-Cluster Traffic
for cluster in mc1 mc2;
do
  kubectx $cluster
  kubectl wait -n sample --for=condition=ready pod -l app=helloworld
done

kubectx mc1
for _ in {1..10};
do
  kubectl exec -n sample -c sleep \
      "$(kubectl get pod -n sample -l \
      app=sleep -o jsonpath='{.items[0].metadata.name}')" \
      -- curl -sS helloworld.sample:5000/hello
done

# Expected that get responses from v1 and v2
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd