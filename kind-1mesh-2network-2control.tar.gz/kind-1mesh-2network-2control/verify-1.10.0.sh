# VAR setup istio version
ISTIO=../istio-1.10.0

# Verify galera still works in one cluster
kind load docker-image jimlintw/mariadb:10.6.3-latest --name mesh-cluster1
kind load docker-image jimlintw/mariadb:10.6.3-latest --name mesh-cluster2

for cluster in mc1 mc2;
do
  kubectx $cluster
  kubectl create namespace cluster1
  kubectl create namespace cluster2
  kubectl create namespace cluster3

  for ns in cluster1 cluster2 cluster3;
  do
    kubectl label namespace $ns istio-injection=enabled
    kubectl apply -n $ns -f - <<EOF
apiVersion: security.istio.io/v1beta1
kind: PeerAuthentication
metadata:
  name: default
spec:
  mtls:
    mode: DISABLE
EOF
  done

  kubectl apply -f ../../mariadb-galera/node1-svc.yaml
  kubectl apply -f ../../mariadb-galera/node2-svc.yaml
  kubectl apply -f ../../mariadb-galera/node3-svc.yaml
done

kubectx mc1
kubectl apply -f ../../mariadb-galera/node1.yaml
kubectl apply -f ../../mariadb-galera/node2.yaml

# Verify galera still works in two cluster
kubectx mc2
kubectl apply -f ../../mariadb-galera/node3.yaml

# Debug (https://istio.io/latest/docs/ops/diagnostic-tools/proxy-cmd/)

  # Get an overview of your mesh
for cluster in mc1 mc2;
do
  kubectx $cluster
  $ISTIO/bin/istioctl proxy-status
done

  # Retrieve diffs between Envoy and Istiod
$ISTIO/bin/istioctl --context mc2 proxy-status nginx-0.sample

  # Deep dive into Envoy configuration
  # To get a basic summary of clusters, listeners or routes for a given pod use the command as follows
for cluster in mc1 mc2;
do
  kubectx $cluster
  $ISTIO/bin/istioctl proxy-config cluster -n sample $(kubectl get pod -n sample -l app=sleep -o jsonpath='{.items[0].metadata.name}')
done

for cluster in mc1 mc2;
do
  kubectx $cluster
  $ISTIO/bin/istioctl proxy-config listeners -n sample $(kubectl get pod -n sample -l app=sleep -o jsonpath='{.items[0].metadata.name}')
done

for cluster in mc1 mc2;
do
  kubectx $cluster
  $ISTIO/bin/istioctl proxy-config routes -n sample $(kubectl get pod -n sample -l app=sleep -o jsonpath='{.items[0].metadata.name}')
done 

for cluster in mc1 mc2;
do
  kubectx $cluster
  $ISTIO/bin/istioctl proxy-config endpoints -n sample $(kubectl get pod -n sample -l app=sleep -o jsonpath='{.items[0].metadata.name}')
done 
