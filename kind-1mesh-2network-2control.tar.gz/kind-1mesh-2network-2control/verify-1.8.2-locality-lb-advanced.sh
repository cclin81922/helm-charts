# VAR setup istio version
ISTIO=../istio-1.8.2

# clean sample namesapce
for cluster in mc1 mc2
do 
    kubectl --context="$cluster" delete ns sample
done

# https://istio.io/latest/docs/tasks/traffic-management/locality-load-balancing/

kubectl --context mc1 label node mesh-cluster1-control-plane topology.kubernetes.io/region=region1 --overwrite
kubectl --context mc2 label node mesh-cluster2-control-plane topology.kubernetes.io/region=region2 --overwrite

# Verify endpoint discovery

  # 1. Install sample application
for cluster in mc1 mc2;
do
  kubectx $cluster
  kubectl create namespace sample
  kubectl label namespace sample istio-injection=enabled
  kubectl apply -f $ISTIO/samples/helloworld/helloworld.yaml -l service=helloworld -n sample
  kubectl apply -f $ISTIO/samples/sleep/sleep.yaml -n sample

  kubectl apply -n sample -f - <<EOF
apiVersion: security.istio.io/v1beta1
kind: PeerAuthentication
metadata:
  name: default
spec:
  mtls:
    mode: STRICT
EOF
done

kubectl --context mc1 apply -f $ISTIO/samples/helloworld/helloworld.yaml -l version=v1 -n sample
kubectl --context mc2 apply -f $ISTIO/samples/helloworld/helloworld.yaml -l version=v2 -n sample

  # 2. Verifying Cross-Cluster Traffic
for cluster in mc1 mc2;
do
  kubectx $cluster
  kubectl wait -n sample --timeout 1m --for=condition=ready pod -l app=helloworld
done

kubectx mc1
for _ in {1..10};
do
  kubectl exec -n sample -c sleep \
      "$(kubectl get pod -n sample -l \
      app=sleep -o jsonpath='{.items[0].metadata.name}')" \
      -- curl -sS helloworld.sample:5000/hello
done

# Expected that get responses from v1 and v2
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd

cat <<EOF > verify-1.8.2-locality/locality-failover-r1-to-r2.yaml
apiVersion: networking.istio.io/v1beta1
kind: DestinationRule
metadata:
  name: helloworld
spec:
  host: helloworld.sample.svc.cluster.local
  trafficPolicy:
    connectionPool:
      http:
        maxRequestsPerConnection: 1
    loadBalancer:
      simple: ROUND_ROBIN
      localityLbSetting:
        enabled: true
        failover:
          - from: region1
            to: region2
    outlierDetection:
      consecutive5xxErrors: 1
      interval: 1s
      baseEjectionTime: 1m
EOF

kubectl --context mc1 apply -n sample -f verify-1.8.2-locality/locality-failover-r1-to-r2.yaml

kubectx mc1
for _ in {1..10};
do
  kubectl exec -n sample -c sleep \
      "$(kubectl get pod -n sample -l \
      app=sleep -o jsonpath='{.items[0].metadata.name}')" \
      -- curl -sS helloworld.sample:5000/hello
done
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg

kubectx mc2
for _ in {1..10};
do
  kubectl exec -n sample -c sleep \
      "$(kubectl get pod -n sample -l \
      app=sleep -o jsonpath='{.items[0].metadata.name}')" \
      -- curl -sS helloworld.sample:5000/hello
done
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd
# Hello version: v2, instance: helloworld-v2-54df5f84b-jk79j
# Hello version: v1, instance: helloworld-v1-776f57d5f6-xprhd

cat <<EOF > verify-1.8.2-locality/locality-failover-r2-to-r1.yaml
apiVersion: networking.istio.io/v1beta1
kind: DestinationRule
metadata:
  name: helloworld
spec:
  host: helloworld.sample.svc.cluster.local
  trafficPolicy:
    connectionPool:
      http:
        maxRequestsPerConnection: 1
    loadBalancer:
      simple: ROUND_ROBIN
      localityLbSetting:
        enabled: true
        failover:
          - from: region2
            to: region1
    outlierDetection:
      consecutive5xxErrors: 1
      interval: 1s
      baseEjectionTime: 1m
EOF

kubectl --context mc2 apply -n sample -f verify-1.8.2-locality/locality-failover-r2-to-r1.yaml
#Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
#Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
#Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
#Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
#Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
#Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
#Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
#Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
#Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
#Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff

# simulate failover (r1 to r2)
kubectx mc1
kubectl exec \
  "$(kubectl get pod -n sample -l app=helloworld \
  -o jsonpath='{.items[0].metadata.name}')" \
  -n sample -c istio-proxy -- curl -sSL -X POST 127.0.0.1:15000/drain_listeners
# OK

kubectx mc1
for _ in {1..10};
do
  kubectl exec -n sample -c sleep \
      "$(kubectl get pod -n sample -l \
      app=sleep -o jsonpath='{.items[0].metadata.name}')" \
      -- curl -sS helloworld.sample:5000/hello
done
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff

# simulate failback
kubectx mc1
kubectl delete po \
  "$(kubectl get pod -n sample -l app=helloworld \
  -o jsonpath='{.items[0].metadata.name}')" \
  -n sample

kubectx mc1
for _ in {1..10};
do
  kubectl exec -n sample -c sleep \
      "$(kubectl get pod -n sample -l \
      app=sleep -o jsonpath='{.items[0].metadata.name}')" \
      -- curl -sS helloworld.sample:5000/hello
done
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg

# simulate failover (r2 to r1)
kubectx mc2
kubectl exec \
  "$(kubectl get pod -n sample -l app=helloworld \
  -o jsonpath='{.items[0].metadata.name}')" \
  -n sample -c istio-proxy -- curl -sSL -X POST 127.0.0.1:15000/drain_listeners
# OK

kubectx mc2
for _ in {1..10};
do
  kubectl exec -n sample -c sleep \
      "$(kubectl get pod -n sample -l \
      app=sleep -o jsonpath='{.items[0].metadata.name}')" \
      -- curl -sS helloworld.sample:5000/hello
done

# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg
# Hello version: v1, instance: helloworld-v1-776f57d5f6-h87vg

# simulate failback
kubectx mc2
kubectl delete po \
  "$(kubectl get pod -n sample -l app=helloworld \
  -o jsonpath='{.items[0].metadata.name}')" \
  -n sample

kubectx mc2
for _ in {1..10};
do
  kubectl exec -n sample -c sleep \
      "$(kubectl get pod -n sample -l \
      app=sleep -o jsonpath='{.items[0].metadata.name}')" \
      -- curl -sS helloworld.sample:5000/hello
done
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff
# Hello version: v2, instance: helloworld-v2-54df5f84b-ch2ff