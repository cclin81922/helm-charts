# Clean namespaces
for cluster in mc1 mc2;
do
    kubectx $cluster
    kubectl delete ns sample
done

for cluster in mc1 mc2;
do
    kubectx $cluster
    kubectl delete ns cluster3
done

for cluster in mc1 mc2;
do
    kubectx $cluster
    kubectl delete ns cluster2
done

for cluster in mc1 mc2;
do
    kubectx $cluster
    kubectl delete ns cluster1
done

# Clean clusters
kind delete cluster --name mesh-cluster1
kind delete cluster --name mesh-cluster2

# Clean kubeconfig contexts
kubectl config delete-context mc1
kubectl config delete-context mc2
kubectx docker-desktop