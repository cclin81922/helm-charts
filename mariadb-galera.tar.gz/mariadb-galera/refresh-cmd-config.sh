kubectl -n cluster1 delete cm cmd-config
kubectl -n cluster1 create cm cmd-config --from-file=cmd.sh