#!/bin/bash

if [ ${BOOTSTRAP} -eq 1 ]; then
#   docker-entrypoint.sh mysqld --wsrep-new-cluster --wsrep-on=1 --wsrep-provider=/usr/lib/libgalera_smm.so --wsrep-cluster-address=gcomm://db-0.db-headless.cluster1.svc.cluster.local,db-0.db-headless.cluster2.svc.cluster.local,db-0.db-headless.cluster3.svc.cluster.local --binlog-format=ROW --default-storage-engine=InnoDB --innodb-autoinc-lock-mode=2 --innodb-doublewrite=1 --query-cache-size=0
    docker-entrypoint.sh mysqld --wsrep-new-cluster --wsrep-on=1 --wsrep-provider=/usr/lib/libgalera_smm.so --wsrep-cluster-address=gcomm://db.cluster1.svc.cluster.local,db.cluster2.svc.cluster.local,db.cluster3.svc.cluster.local --binlog-format=ROW --default-storage-engine=InnoDB --innodb-autoinc-lock-mode=2 --innodb-doublewrite=1 --query-cache-size=0
else
#   docker-entrypoint.sh mysqld --wsrep-on=1 --wsrep-provider=/usr/lib/libgalera_smm.so --wsrep-cluster-address=gcomm://db-0.db-headless.cluster1.svc.cluster.local,db-0.db-headless.cluster2.svc.cluster.local,db-0.db-headless.cluster3.svc.cluster.local --binlog-format=ROW --default-storage-engine=InnoDB --innodb-autoinc-lock-mode=2 --innodb-doublewrite=1 --query-cache-size=0
    docker-entrypoint.sh mysqld --wsrep-on=1 --wsrep-provider=/usr/lib/libgalera_smm.so --wsrep-cluster-address=gcomm://db.cluster1.svc.cluster.local,db.cluster2.svc.cluster.local,db.cluster3.svc.cluster.local --binlog-format=ROW --default-storage-engine=InnoDB --innodb-autoinc-lock-mode=2 --innodb-doublewrite=1 --query-cache-size=0
fi