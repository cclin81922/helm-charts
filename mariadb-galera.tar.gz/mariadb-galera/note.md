#!/bin/bash

docker-entrypoint.sh mysqld

wsrep_provider — Path to the Galera library
wsrep_cluster_address — See Galera Cluster address format and usage
binlog_format=ROW — See Binary Log Formats
default_storage_engine=InnoDB
innodb_autoinc_lock_mode=2
innodb_doublewrite=1 — This is the default value, but it should not be changed when using Galera provider version >= 2.0.
query_cache_size=0 — Only mandatory for MariaDB versions prior to MariaDB Galera Cluster 5.5.40, MariaDB Galera Cluster 10.0.14, and MariaDB 10.1.2.
wsrep_on=ON — Enable wsrep replication (starting 10.1.1)

--defaults-file=/opt/bitnami/mariadb/conf/my.cnf 
--basedir=/opt/bitnami/mariadb 
--datadir=/bitnami/mariadb/data 
--socket=/opt/bitnami/mariadb/tmp/mysql.sock 
--pid-file=/opt/bitnami/mariadb/tmp/mysqld.pid

[galera]
wsrep_on=ON
wsrep_provider=/opt/bitnami/mariadb/lib/libgalera_smm.so
wsrep_sst_method=mariabackup
wsrep_slave_threads=4
wsrep_cluster_address=gcomm://
wsrep_sst_auth=mariabackup:KJbO1ZGg2I
wsrep_cluster_name=galera
wsrep_node_name=my-release-mariadb-galera-0
wsrep_node_address=10.1.0.39

[galera]
wsrep_on=ON
wsrep_provider=/opt/bitnami/mariadb/lib/libgalera_smm.so
wsrep_sst_method=mariabackup
wsrep_slave_threads=4
wsrep_cluster_address=gcomm://my-release-mariadb-galera-headless.default.svc.cluster.local
wsrep_sst_auth=mariabackup:KJbO1ZGg2I
wsrep_cluster_name=galera
wsrep_node_name=my-release-mariadb-galera-1
wsrep_node_address=10.1.0.40

[galera]
wsrep_on=ON
wsrep_provider=/opt/bitnami/mariadb/lib/libgalera_smm.so
wsrep_sst_method=mariabackup
wsrep_slave_threads=4
wsrep_cluster_address=gcomm://my-release-mariadb-galera-headless.default.svc.cluster.local
wsrep_sst_auth=mariabackup:KJbO1ZGg2I
wsrep_cluster_name=galera
wsrep_node_name=my-release-mariadb-galera-2
wsrep_node_address=10.1.0.41