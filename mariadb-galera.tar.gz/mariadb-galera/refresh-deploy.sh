kubectl delete -f node1.yaml 
kubectl delete -f node2.yaml
kubectl delete -f node3.yaml
bash build.sh
kubectl apply -f node1.yaml
kubectl apply -f node2.yaml
kubectl apply -f node3.yaml